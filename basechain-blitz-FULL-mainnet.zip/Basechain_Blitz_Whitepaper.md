
# Basechain Blitz Whitepaper

- Flappy-style arcade gameplay
- On-chain PoW score minting
- Weekly leaderboard snapshot
- $GMMC reward pool (Base mainnet)
