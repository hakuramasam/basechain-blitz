
console.log("Indexer running: listening to ScorePoW events");
