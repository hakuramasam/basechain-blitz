
# Basechain Blitz

Base mainnet arcade game with on-chain PoW scores and weekly $GMMC rewards.
