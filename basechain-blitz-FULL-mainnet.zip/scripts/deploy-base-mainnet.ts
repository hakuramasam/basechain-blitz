
import { ethers, run } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();

  const ScorePoW = await ethers.getContractFactory("ScorePoW");
  const scorePoW = await ScorePoW.deploy();
  await scorePoW.waitForDeployment();

  const RewardPool = await ethers.getContractFactory("RewardPool");
  const rewardPool = await RewardPool.deploy(process.env.GMMC_TOKEN!);
  await rewardPool.waitForDeployment();

  console.log("ScorePoW:", await scorePoW.getAddress());
  console.log("RewardPool:", await rewardPool.getAddress());

  await new Promise(r => setTimeout(r, 25000));

  await run("verify:verify", {
    address: await scorePoW.getAddress(),
    constructorArguments: []
  });

  await run("verify:verify", {
    address: await rewardPool.getAddress(),
    constructorArguments: [process.env.GMMC_TOKEN]
  });
}

main().catch(console.error);
